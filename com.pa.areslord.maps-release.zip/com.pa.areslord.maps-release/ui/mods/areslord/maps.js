cShareSystems.load_pas("ARESLORD lawful exotic 3v3 & 4v4 & 5v5", [
    "coui://ui/mods/areslord/systems/deadly_craters_4v4_ns.pas",
	"coui://ui/mods/areslord/systems/toclafane_4v4_ns.pas",
    "coui://ui/mods/areslord/systems/atat_4v4_ns.pas",
    "coui://ui/mods/areslord/systems/exocanyons_4v4_ns.pas",
    "coui://ui/mods/areslord/systems/exocanyons_4v4_ns_more_metal.pas",
    "coui://ui/mods/areslord/systems/battleship_5v5_ns.pas",
    "coui://ui/mods/areslord/systems/nipple_grenades_3v3_ns.pas",
	"coui://ui/mods/areslord/systems/water_nipple_grenade_3v3_ns.pas"
]);
cShareSystems.load_pas("ARESLORD Chaotic exotic 4v4 & 5v5", [
    "coui://ui/mods/areslord/systems/lord_of the rings_2v2v2v2_or_4v4_ns_8p.pas",
    "coui://ui/mods/areslord/systems/maze2_4v4_ns.pas",
    "coui://ui/mods/areslord/systems/maze2_5v5_ns.pas",
    "coui://ui/mods/areslord/systems/maze3_4v4_ns.pas",
    "coui://ui/mods/areslord/systems/plank_4v4_ns.pas",
    "coui://ui/mods/areslord/systems/plaques_2v2_ns_or_4ffa.pas",
    "coui://ui/mods/areslord/systems/plaques_8p_teamsffa.pas"
]);
